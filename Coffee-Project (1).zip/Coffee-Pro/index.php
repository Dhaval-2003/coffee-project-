<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Welcome to Coffee Shop - The best Coffee</title>
  <meta content="" name="description">

  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="https://cdn.shopify.com/s/files/1/1697/1767/files/drivecoffee-logo-rgb-black_410x.png?v=1509322274" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous"> -->
  <style>
    body {
      position: relative;
    }

    .error {
      display: none;
      position: absolute;
      height: 5vh;
      width: 100%;
    }

    .errorbody {
      background-color: #4BB543;
      color: #fff;
      text-align: center;
    }
  </style>
</head>

<body>

  <!-- ======= Header ======= -->

  <?php
  require('partials/nav.php');
  ?>
  <div>
    <div class="error" id="error">
      <div class="errorbody">
        <span>Your Order Has been Purchased</span>
      </div>
    </div>
    <?php
    if (isset($_GET['status']) == "true") {
      echo "<script>document.getElementById('error').style.display='block';

            const v = setTimeout(out,5000);
          function out(){
          document.getElementById('error').style.display='none';

          }</script>";
    }
    ?>
  </div>
  <main id="main">

    <!-- This is the section of slider-->
    <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel" style="margin-top: 80px;" data-aos="fade-up ">
      <div class="carousel-indicators">
        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="3" aria-label="Slide 4"></button>
      </div>
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="https://images.pexels.com/photos/2159065/pexels-photo-2159065.jpeg" class="d-block w-100" alt="...">
        </div>
        <div class="carousel-item">
          <img src="https://images.pexels.com/photos/143642/pexels-photo-143642.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" class="d-block w-100" alt="...">
        </div>
        <div class="carousel-item">
          <img src="https://images.pexels.com/photos/702251/pexels-photo-702251.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" class="d-block w-100" alt="...">
        </div>
        <div class="carousel-item">
          <img src="https://images.pexels.com/photos/849645/pexels-photo-849645.jpeg" class="d-block w-100" alt="...">
        </div>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>
   <hr>
    <!-- Welcome Section-->
    <div class="d-flex container-fluid flex-column align-items-center justify-content-center" id="about" data-aos="fade-up">
      <h1 style="font-weight: 700;">Welcome to Coffee Shop</h1>
      <p class="text-align-center container">The story goes that that Kaldi discovered coffee after he noticed that after eating the berries from a certain tree, his goats became so energetic that they did not want to sleep at night.</p>
    </div>
    <hr>
    <div class="container-fluid" data-aos="fade-up">
      <h1 class="text-center" style="color: #265baa;">Category</h1>
      <div class="row row-cols-2" data-aos="fade-up">
        <div class="col"><img src="https://images.pexels.com/photos/374852/pexels-photo-374852.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" alt="" width="650"></div>
        <div class="col d-flex align-items-center flex-column justify-content-center" style="background-image: linear-gradient(to right,#bfd9ff,#fff);height:100px; color:black;position:relative;    font-size: 20px;
      font-weight: 510;
     top:90px;">
          <a href="product.php?name=pendent">
            <p class="text-center">Black Coffee</p>
            <p class="text-center">Explore</p>
          </a>
        </div>
      </div>

      <div class="row row-cols-2" data-aos="fade-up">
        <div class="col d-flex align-items-center flex-column justify-content-center" style="background-image: linear-gradient(to right,#bfd9ff,#fff);height:100px; color:black;position:relative;
      top:90px;font-size: 20px;
      font-weight: 510;">
          <a href="product.php?name=earring">
            <p class="text-center">Arabica Coffee</p>
            <p class="text-center">Explore</p>
          </a>
        </div>
        <div class="col"><img src="https://images.pexels.com/photos/2299029/pexels-photo-2299029.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" alt="" width="650"></div>
      </div>

      <div class="row row-cols-2" data-aos="fade-up">
        <div class="col"><img src="https://images.pexels.com/photos/7407225/pexels-photo-7407225.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" alt="" width="650"></div>
        <div class="col d-flex align-items-center flex-column justify-content-center" style="background-image: linear-gradient(to right,#bfd9ff,#fff);height:100px; color:black;position:relative;
      top:90px;font-size: 20px;
      font-weight: 510;">
          <a href="product.php?name=ring">
            <p class="text-center">Robusta Coffee</p>
            <p class="text-center">Explore</p>
          </a>
        </div>
      </div>
    </div>
    <hr>
           
    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials">

      <div class="container" data-aos="fade-up">

        <header class="section-header">
          <h2>Testimonials</h2>
          <p>What are they saying about Our Product</p>
        </header>

        <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="200">
          <div class="swiper-wrapper">

            <div class="swiper-slide">
              <div class="testimonial-item">
                <div class="stars">
                  <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                </div>
                <p>
                I really like the atmosphere, good coffee, and nice interior. This is a good place to study or chill with friends. The drinks and foods were all tasty and worthwhile. If you’re up for a fresh place with beautiful architecture then this is a must to visit.
                </p>
                <div class="profile mt-auto">
                  <img src="assets/img/testimonials/testimonials-1.jpg" class="testimonial-img" alt="">
                  <h3>Saul Goodman</h3>
                  <h4>Customer</h4>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <div class="stars">
                  <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                </div>
                <p>
                This place is amazing! They offered the best coffee and showed the best attitude to its costumers. Internet connection is very fast and is unlimited as well. This place is indeed perfect for studying and chilling out. It was very quiet and air-conditioned. I just want to keep coming back to this place. Thank you!
                </p>
                <div class="profile mt-auto">
                  <img src="assets/img/testimonials/testimonials-2.jpg" class="testimonial-img" alt="">
                  <h3>Sara Wilsson</h3>
                  <h4>Customer</h4>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <div class="stars">
                  <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                </div>
                <p>
                I would probably say that this coffee shop is a must for coffee lovers! The service was good, and the variety of coffee served in the ambiance was very satisfying. If you like your coffee shops, then this is a must-visit! We will be back again!
                </p>
                <div class="profile mt-auto">
                  <img src="assets/img/testimonials/testimonials-3.jpg" class="testimonial-img" alt="">
                  <h3>Jena Karlis</h3>
                  <h4>Customer</h4>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <div class="stars">
                  <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
                </div>
                <p>
                This place is very different and well organized according to other places. The food is amazing, music of your choice. The owner is very sweet… Ever the best café. The cost is fair for everything and the atmosphere is good.
                </p>
                <div class="profile mt-auto">
                  <img src="assets/img/testimonials/testimonials-4.jpg" class="testimonial-img" alt="">
                  <h3>Matt Brandon</h3>
                  <h4>Kiran Diamonds</h4>
                </div>
              </div>
            </div><!-- End testimonial item -->


          </div>
          
        </div>

      </div>

    </section><!-- End Testimonials Section -->
    

  

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php
  include "partials/footer.php"; ?>

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>