<?php
session_start();
$name = $_SESSION['name'];
$price = $_GET['price'];
$_SESSION['price'] = $price;
$email = $_SESSION['email'];
// echo "Your Name is : $name </br> Your Total Price is: $price " . "<br> test";
require "partials/connection.php";
// $sql = "SELECT * from `user_info` where `email`='$email'";
// $result = mysqli_query($con, $sql);
// print_r(mysqli_fetch_array($result));
// $sql="SELECT * from `cart` where `username`='$name'";


if (isset($_POST['submit'])) {
    $address = $_POST['address'];
    $sql = "INSERT INTO `order_confirmed` (`username`,`price`,`address`) VALUES('$name','$price','$address')";
    $result = mysqli_query($con, $sql);
    if ($result) {
        $sql = "DELETE FROM `cart` where `username`='$name'";
        if (mysqli_query($con, $sql)) {
            header("location:index.php?status=true");
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link href="https://cdn.shopify.com/s/files/1/1697/1767/files/drivecoffee-logo-rgb-black_410x.png?v=1509322274" rel="icon">
    <style>
        .main {
            display: flex;
            font-size: 20px;
            justify-content: center;
            align-items: center;
            border: 1px solid grey;
            background-color: #f2f2f2;
        }

        .form1 {
            margin: 10px;
            display: flex;
            flex-direction: column;
            width: 30vw;
        }

        .form1 input {
            width: 25vw;
            height: 5vh;
        }

        .inner-form1 {
            display: flex;
        }

        .inner-form1 input {
            width: 10vw;
            margin: 0 5px;
        }

        .form2 {
            margin: 0 10px;
            display: flex;
            flex-direction: column;
        }

        .form2 div i {
            margin: 0 5px;
            font-size: 25px;
        }

        .form2 input {
            width: 15vw;
            height: 5vh;
        }

        .inner-form2 {
            display: flex;
        }

        .inner-form2 input {
            width: 5vw;
            margin: 0 5px;
        }

        .submit {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }

        label {
            margin: 5px 0;
        }

        .submit label {
            font-size: 25px;
        }

        .submit input {
            width: 30vw;
            height: 5vh;
            margin: 5px;
            background: #265baa;
            border: none;
            color: white;
            border-radius: 5px;
        }

        .chek {
            display: flex;
            align-items: center;
        }

        .chek input {
            width: auto;
            font-size: 15px;
        }
    </style>
</head>

<body>
    <form action="" method="post">
        <div class="main">
            <div class="form1">
                <h3>Billing Address</h3>
                <label for=""><i class="fa-solid fa-user" style="margin: 0 5px;"></i>Full Name:</label>
                <input type="text" name="fname" placeholder="Enter First Name" value="<?php echo $name; ?>">
                <label for=""><i class="fa-solid fa-envelope" style="margin: 0 5px;"></i>Email:</label>
                <input type="email" name="email" placeholder="Enter Email">
                <label for=""><i class="fa-solid fa-address-card" style="margin: 0 5px;"></i>Address:</label>
                <input type="text" name="address" placeholder="Enter Address">
                <label for=""><i class="fa-solid fa-city" style="margin: 0 5px;"></i>City:</label>
                <input type="text" name="city" placeholder="Enter City">
                <div class="inner-form1">
                    <div class="inner">
                        <label for="">State</label><br>
                        <input type="text" name="state" placeholder="Gujarat">
                    </div>
                    <div class="inner2">
                        <label for="">Zip</label><br>
                        <input type="text" name="zip" placeholder="395001">
                    </div>
                </div>
                <div class="chek"><input type="radio" value="Cash" name="cod" checked>Cash on Delivery</div>
            </div>
            <!-- <div class="form2">
                <h3>Payment</h3>
                <label for="">Accepted Cards</label>
                <div><i class="fa-brands fa-cc-visa" style="color: navy;"></i><i class="fa-brands fa-cc-amex" style="color: blue;"></i><i class="fa-brands fa-cc-discover" style="color: orange;"></i></div>
                <label for="">Name on card:</label>
                <input type="text" name="fname" placeholder="Enter Name on card">
                <label for="">Credit Card Number:</label>
                <input type="number" name="fname" placeholder="Enter card number" maxlength="16">
                <label for="">Expiration Month:</label>
                <input type="text" name="fname" placeholder="Enter Expiration Month">
                <div class="inner-form2">
                    <div class="inner">
                        <label for="">Exp Year</label><br>
                        <input type="text" name="state" placeholder="Year">
                    </div>
                    <div class="inner2">
                        <label for="">CVV</label><br>
                        <input type="password" name="state" placeholder="CVV">
                    </div>
                </div>
            </div> -->
        </div>
        <div class="submit">
            <label for="">Your Have To Pay:<?php echo $price; ?></label>
            <input type="submit" value="Continue to Checkout" name="submit">
        </div>
    </form>
</body>

</html>