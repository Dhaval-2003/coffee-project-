<?php
session_start();
$name=$_SESSION['name'];
$email=$_SESSION['email'];
    require "partials/connection.php";
    $sql="SELECT * from `user_info` where `email`='$email'";
    $result=mysqli_query($con,$sql);
    $row=mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link href="https://cdn.shopify.com/s/files/1/1697/1767/files/drivecoffee-logo-rgb-black_410x.png?v=1509322274" rel="icon">
    <style>
        body {
            background-image: linear-gradient(to bottom right, #E3F0FF, #FAFCFF);
            height: 95vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .container {
            width: 70%;
            height: 80%;
            background-color: #ffffff;
            border-radius: 20px;
            box-shadow: 0px 25px 40px #1687d933;
        }
        .container h3{
            text-align: center;
            font-size: 30px;
        }
        .container table{
            font-size: 20px;
        }
        table{
            position: relative;
        }
        .main{
            display: flex;
            justify-content: space-evenly;
            align-items: center;
        }
        .update{
            border-radius: 10px;
            background-color: #265baa;
            color: white;
            width: 10vw;
            height: 5vh;
            text-align: center;
            cursor: pointer;
            text-decoration: none;
            font-size: 20px;
            border: 1px solid transparent;
            margin: 0 5px;
        }
        .main2{
            display: flex;
            justify-content: center;
            align-items: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h3>Your Profile</h3>
        <div class="main">
        <table>
            <tr>
                <td>First Name:</td>
            </tr>
            <tr></tr>
            <tr>
                <td>Last Name:</td>
            </tr>
            <tr></tr>
            <tr>
                <td>Email:</td>
            </tr>
            <tr></tr>
            <tr>
                <td>Country:</td>
            </tr>
            <tr></tr>
            <tr>
                <td>Your Total Order is:</td>
            </tr>
        </table>
        <table>
            <tr>
                <td><?php echo $row['fname']; ?></td>
            </tr>
            <tr>
                <td><?php echo $row['lname']; ?></td>
            </tr>
            <tr>
                <td><?php echo $row['email']; ?></td>
            </tr>
            <tr>
                <td><?php echo $row['country'];?> </td>
            </tr>
            <?php $sql="SELECT * from `order_confirmed` where `username`='$name'";
            $result=mysqli_query($con,$sql);
            $row=mysqli_num_rows($result);
            ?>
            <tr><td><?php echo $row;?></td></tr>
        </table>
        </div>
        <div class="main2">
        <a class="update" href="update.php">Update</a>
        <a class="update" href="index.php">Home Page</a>

        </div>
    </div>
</body>
</html>