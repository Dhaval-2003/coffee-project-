<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <!-- <link href="assets/icon.png" rel="favicon"> -->
    <link rel="shortcut icon" href="assets/icon.png" type="image/x-icon">
    <style>
        table {
            border-collapse: collapse;
            width: 60vw;
            text-align: center;
        }

        body {
            background-image: linear-gradient(to bottom right, #E3F0FF, #FAFCFF);
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .container {
            width: 70%;
            height: 85%;
            background-color: #ffffff;
            border-radius: 20px;
            box-shadow: 0px 25px 40px #1687d933;
        }

        .Header {
            display: flex;
            margin: auto;
            height: 15%;
            width: 90%;
            align-items: center;
            justify-content: space-between;
        }

        .Heading {
            color: #265baa;
        }

        .Action {
            color: #ff0000;
            text-decoration: underline;
            cursor: pointer;
            background: transparent;
            border: none;
        }

        .Cart-Items {
            margin: auto;
            width: 90%;
            height: 30%;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .image-box {
            width: 15%;
            text-align: center;
        }

        .about {
            height: 100%;
        }

        .title {
            padding-top: 5px;
            line-height: 10px;
            font-size: 32px;
            font-family: 'Open Sans';
            font-weight: 800;
            color: #202020;
        }

        .subtitle {
            line-height: 10px;
            font-size: 18px;
            font-family: 'Open Sans';
            font-weight: 600;
            color: #909090;
        }

        .Cart-Items {
            margin: auto;
            width: 90%;
            height: 30%;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .image-box {
            width: 15%;
            text-align: center;
        }

        .about {
            height: 100%;
        }

        .title {
            padding-top: 5px;
            line-height: 10px;
            font-size: 32px;
            font-family: 'Open Sans';
            font-weight: 800;
            color: #202020;
        }

        .subtitle {
            line-height: 10px;
            font-size: 18px;
            font-family: 'Open Sans';
            font-weight: 600;
            color: #909090;
        }

        .counter {
            width: 15%;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #d9d9d9;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 20px;
            font-family: 'Open Sans';
            font-weight: 900;
            color: #202020;
            cursor: pointer;
            border: none;
        }

        .count {
            font-size: 20px;
            font-family: 'Open Sans';
            font-weight: 900;
            color: #202020;
        }

        .prices {
            height: 100%;
            text-align: right;
        }

        .amount {
            padding-top: 20px;
            font-size: 26px;
            font-family: ‘Open Sans’;
            font-weight: 800;
            color: #202020;
        }

        .save {
            padding-top: 5px;
            font-size: 14px;
            font-family: 'Open Sans';
            font-weight: 600;
            color: #1687d9;
            cursor: pointer;
        }

        .remove {
            padding-top: 5px;
            font-size: 14px;
            font-family: 'Open Sans';
            font-weight: 600;
            color: #E44C4C;
            cursor: pointer;
        }

        hr {
            width: 66%;
            float: right;
            margin-right: 5%;
        }

        .checkout {
            float: right;
            margin-right: 5%;
            width: 28%;
        }

        .total {
            width: 100%;
            display: flex;
            justify-content: space-between;
        }

        .Subtotal {
            font-size: 22px;
            font-family: 'Open Sans';
            font-weight: 700;
            color: #202020;
        }

        .items {
            font-size: 16px;
            font-family: 'Open Sans';
            font-weight: 500;
            color: #909090;
            line-height: 10px;
        }

        .total-amount {
            font-size: 36px;
            font-family: 'Open Sans';
            font-weight: 900;
            color: #202020;
        }

        .button {
            margin-top: 5px;
            width: 100%;
            height: 40px;
            border: none;
            background: linear-gradient(to bottom right, #B8D7FF, #8EB7EB);
            border-radius: 20px;
            cursor: pointer;
            font-size: 16px;
            font-family: 'Open Sans';
            font-weight: 600;
            color: #202020;
        }
    </style>
</head>

<body>
    <div class='container'>
        <div class='Header'>
            <h3 class='Heading'>Shopping Cart</h3>
            <a class='Action' href="cart_insert.php?all=true">Remove all</a>
        </div>
        <?php
        require "partials/connection.php";
        if (isset($_SESSION['name'])) {
            $user = $_SESSION['name'];
            $sql = "SELECT * FROM `cart` where `username`='$user'";
            $result = mysqli_query($con, $sql);
            $sum = 0;
            $count = 0;
            if (mysqli_num_rows($result) > 0) {
                echo "";
                $i = 0;
                $count = mysqli_num_rows($result);
                while ($row = mysqli_fetch_array($result)) {
                    echo '<div class="Cart-Items">
    <div class="image-box">
    <img src=product/' . $row['image'] . ' style="height:120px;"/>
    </div>
    <div class="about">
    <h1 class="title">' . $row['product_name'] . '</h1>
    </div>
    <div class="counter"><button class="btn" onclick="maxq(' . $i . ',' . $row['price'] . ',' . $count . ')">+</button>
    <div class="count" id="counter' . $i . '">1</div>
    <input type="hidden" id="qty' . $i . '" value="1">
    <button class="btn" onclick="mini(' . $i . ',' . $row['price'] . ',' . $i . ')">-</button></div>
    <div class="prices"><div class="amount" id="total' . $i . '">' . $row['price'] . '</div>
    <div class="remove"><a href="cart_insert.php?delete=' . $row['id'] . '">Remove</a></div></div>
    </div>';
                    $sum += $row['price'];
                    // $count++;
                    $i++;
                }
                echo '<hr> 
    <div class="checkout">
        <div class="total">
            <div>
                 <div class="Subtotal">Sub-Total</div>
                 <div class="items" >' . $count . ' Items</div>
            </div>
                
            <div class="total-amount" id="net">' . $sum . '</div> 
        </div>
                
                <button type="submit" class="button" onclick="re()">Checkout</button>
               
      
    </div>';
            } else {
                echo "<h4 align=center>Your Cart Is empty.</h4>";
                echo "<a href='coffee.php' style='display:flex;justify-content:center;'>Back To Product Page</a>";
                echo "</div>";
            }
        } else {
            echo "You Have to Login";
        }
        ?>

        <script>
            var total = 0;

            function re() {
                window.location.href = "checkout.php?price=" + document.getElementById('net').innerHTML;
            }

            function mini(m, v, count2) {
                if (parseInt(document.getElementById('counter' + m).innerHTML) != 1) {
                    document.getElementById('counter' + m).innerHTML = parseInt(document.getElementById('counter' + m).innerHTML) - 1;
                    document.getElementById('qty' + m).value = parseInt(document.getElementById('qty' + m).value) - 1;
                    qty2 = parseInt(document.getElementById('qty' + m).value);
                    document.getElementById('total' + m).innerHTML = parseFloat(v) * qty2;
                    // if (qty2 > 1) {
                    //     for (let i = 0; i <= qty2; i++) {
                    //         // total += parseFloat(document.getElementById('total' + i).innerHTML);
                    //         if (parseInt(document.getElementById('total' + m).innerHTML) > 1)
                    //             document.getElementById('net').innerHTML = Math.abs(parseInt(document.getElementById('total' + (i + 1)).innerHTML) - parseInt(document.getElementById('total' + i).innerHTML));
                    //         else
                    //             document.getElementById('net').innerHTML = parseInt(document.getElementById('total' + i).innerHTML);
                    //     }
                    //     document.getElementById('net').innerHTML = parseFloat(total);
                    // }
                    if (count2 > 1) {
                        if (qty2 > 1) {
                            for (let i = 0; i <= qty2; i++) {
                                document.getElementById('net').innerHTML = Math.abs(parseInt(document.getElementById('total' + (i + 1)).innerHTML) - parseInt(document.getElementById('total' + i).innerHTML));
                            }
                        }
                    } else {
                        document.getElementById('net').innerHTML = document.getElementById('total' + m).innerHTML;
                    }
                }
            }

            function maxq(k, p, count) {
                document.getElementById('counter' + k).innerHTML = parseInt(document.getElementById('counter' + k).innerHTML) + 1;
                document.getElementById('qty' + k).value = parseInt(document.getElementById('qty' + k).value) + 1;

                let qty = parseInt(document.getElementById('qty' + k).value);

                document.getElementById('total' + k).innerHTML = parseFloat(p) * qty;
                console.log(document.getElementById('total' + k).innerHTML);
                console.log(qty);
                //console.log(count);
                if (count > 1) {
                    if (qty > 1) {
                        for (let i = 0; i <= qty; i++) {
                            document.getElementById('net').innerHTML = Math.abs(parseInt(document.getElementById('total' + (i + 1)).innerHTML) + parseInt(document.getElementById('total' + i).innerHTML));
                        }
                    }
                } else {
                    document.getElementById('net').innerHTML = document.getElementById('total' + k).innerHTML;
                }
                console.log(total);
                // document.getElementById('net').innerHTML = parseFloat(total);
            }
        </script>
</body>

</html>