<?php
$name = $_GET['name'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo strtoupper($name); ?></title>
    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link href="https://cdn.shopify.com/s/files/1/1697/1767/files/drivecoffee-logo-rgb-black_410x.png?v=1509322274" rel="icon">
    <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>
    <?php
    require('partials/nav.php');
    ?>
    <div class="container d-flex flex-column justify-content-center align-itmes-center crd">
        <h3 class="text-center"><?php echo strtoupper($name); ?></h3>
        <div class="container d-flex justify-content-center align-items-center my-4" style="position: relative;font-size:20px;">
            <div style="position:absolute;right:56%; ">Product Name</div>
            <div style="position:absolute;right:37%;">Review</div>
            <div style="position: absolute;right:9%;">Add To Cart</div>
        </div>
        <div class="container text-center">
            <div class="row">

                <?php
                require "partials/connection.php";
                $sql = "SELECT * from " . $name . " WHERE `status`='active'";

                $result = mysqli_query($con, $sql);
                if (isset($_SESSION['name'])) {
                    while ($row = mysqli_fetch_array($result)) {
                ?>
                        <!-- <div class="col d-flex justify-content-center flex-column">
                            <a href="cart_insert.php?id=<?php echo $row['id']; ?>&name=<?php echo $name; ?>">
                                <img src=<?php echo 'product/' . $row['image']; ?> alt="">
                            </a>
                            <div class="cart">
                                <a href="cart_insert.php?id=<?php echo $row['id']; ?>&name=<?php echo $name; ?>">
                                    <button><i class="bi bi-cart-fill"></i></button>
                                    <span style="margin: 0px 40px;"><?php echo $row['name']; ?></span>
                                    <i class="bi bi-heart-fill"></i>
                                </a>
                            </div>
                        </div> -->
                        <div id="crd">
                            <div class="row">
                                <div class="col">
                                    <img src=<?php echo 'product/' . $row['image']; ?> alt="" width="200">
                                </div>
                                <div class="col d-flex justify-content-center align-items-center rev">
                                    <div><span style="margin: 0px 10px;"><?php echo $row['name']; ?></span></div>
                                    <div class="star" style="font-size: 20px;"><span>
                                            <?php $select = $row['star'];
                                            $a = 5 - $select;
                                            $j = 1;

                                            for ($i = 1; $i <= $select; $i++) {
                                                echo "★";
                                                if ($i == $select) {
                                                    for ($j = 1; $j <= $a; $j++) {
                                                        echo "☆";
                                                    }
                                                }
                                            } ?> </span></div>
                                    <!-- <div><a href="favorites.php?id=<?php echo $row['id']; ?>&name=<?php echo $name; ?>"><i class="bi bi-heart-fill" style="margin: 0 10px;"></i></a></div> -->
                                </div>
                                <div class="col d-flex align-items-center justify-content-around">
                                    <div><a href="cart_insert.php?id=<?php echo $row['id']; ?>&name=<?php echo $name; ?>">
                                            <button><i class="bi bi-cart-fill"></i></button>
                                        </a></div>
                                </div>
                            </div>
                        </div>
                <?php
                    }
                } else {
                    echo "</div>";
                    echo "<p class='text-center'>You have to be login</p>";
                }
                ?>
            </div>
        </div>
        <script src="assets/vendor/purecounter/purecounter.js"></script>
        <script src="assets/vendor/aos/aos.js"></script>
        <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
        <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
        <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

        <!-- Template Main JS File -->
        <script src="assets/js/main.js"></script>
</body>

</html>