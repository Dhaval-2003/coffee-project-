<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Orders</title>
    <style>
        table {
            text-align: center;
            width: 70vw;
            height: 20vh;
            border-collapse: collapse;
            border: 2px solid #265baa;
            font-size: 15px;
        }
        h3{
            text-align: center;
            font-size: 20px;
            color: #265baa;
        }
        .home{
            display: flex;
            justify-content: center;
            align-items: center;

        }
        .home a{
            text-decoration: none;
            color: #265baa;
            font-size: 20px;
        }
        .home a:hover{
            color: #515151;
        }
    </style>
</head>

<body>
    <pre><h3>Your Orders</h3></pre>
    <?php
    session_start();
    $name = $_SESSION['name'];
    require "partials/connection.php";
    $sql = "SELECT * from `order_confirmed` where username='$name'";
    $result = mysqli_query($con, $sql);
    if (mysqli_num_rows($result) >= -1)
     {
        echo "<pre>";
    ?>
        <table align="center" border="1">
            <tr>
                <th>Order Id:</th>
                <th>Username:</th>
                <th>Your Order Price:</th>
                <!-- <th>Shipping Address</th>
                <th>Purchased At:</th> -->
            </tr>
            <?php
            while ($row = mysqli_fetch_array($result))
            {
            ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['username']; ?></td>
                    <td><?php echo $row['price']; ?></td>
                    <!-- <td><?php echo $row['address']; ?></td>
                    <td><?php echo $row['purchased_at']; ?></td> -->
                </tr>
            <?php
            }
            ?>
        </table>
    <?php
    } else {
        $row = mysqli_fetch_array($result);
        print_r($row);
    ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['username']; ?></td>
            <td><?php echo $row['price']; ?></td>
            <td><?php echo $row['address']; ?></td>
            <td><?php echo $row['purchased_at']; ?></td>

        </tr>
        </table>
    <?php
    }
    ?>
    </pre>
    <div class="home">
        <a href="index.php">Go Back to Home Page</a>
    </div>
</body>

</html>