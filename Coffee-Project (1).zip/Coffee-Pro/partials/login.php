<?php

session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.shopify.com/s/files/1/1697/1767/files/drivecoffee-logo-rgb-black_410x.png?v=1509322274" rel="icon">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    <link rel="stylesheet" href="../forms/form.css">
    <link href="../assets/css/style.css" rel="stylesheet">
    <link href="../assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    <style>
        body {
            background-image: linear-gradient(#4154f1, #2f569f);
            background-repeat: no-repeat;
            height: 82vh;
            font-family: "Nunito", sans-serif;
        }

        table {
            margin-top: 100px;
            background-color: white;
            padding-left: 50px;
            padding-right: 50px;
            border: 1px solid transparent;
            border-radius: 10px;
            height: 300px;
            width: 50vw;
        }

        .form {
            margin-bottom: 80px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        input[type=text],
        input[type=password] {
            padding: 5px;
            height: 7vh;
            padding-left: 10px;
            width: 25vw;
            border: 1px solid grey;
            color: #566D82 !important;
            border-radius: 15px;
        }

        input[type=submit] {
            background-color: #265baa;
            color: white;
            font-size: 13px;
            padding: 18px;
            width: 10vw;
            height: 8vh;
            border: none;
            cursor: pointer;
            border-radius: 10px;
        }
    </style>
</head>

<body>
    <div class="form container-fluid">
        <form action="" method="post">
            <table align="center">
                <tr>
                    <td align="center">Enter Email:</td>
                    <td align="center"><input type="text" name="email" pattern="/^(?=\S[A-Za-z0-9])(?=\@)(?=\S[a-z])(?=\.)(?=in|com)$/"></td>
                </tr>
                <tr>
                    <td align="center">Enter Password:</td>
                    <td align="center"><input type="password" name="password" id=""></td>
                </tr>
                <tr>
                    <td colspan="2" align="center"><input type="submit" value="Login" name="login"></td>
                </tr>
            </table>
        </form>
    </div>

</body>

</html>
<?php

if (isset($_POST['login'])) {
    $con = mysqli_connect('localhost', 'root', '', 'jenish');
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password2 = md5($password);
    // $pattern="/^(?=\S[A-Za-z0-9])\@(?=\S[a-z])(?=\.)(?=in|com)$/";
    $pattern = "/^[A-Za-z0-9]+\@[A-Za-z]+\.in|com/";
    $sql = "SELECT * from `user_info` where `email`='$email'";
    $result = mysqli_query($con, $sql);
    if (preg_match_all($pattern, $email)) {
        if ($result) {
            $row = mysqli_fetch_array($result);
            if ($password2==$row['password']) {
                $_SESSION['name'] = $row['fname']." ".$row['lname'];
                $_SESSION['email'] = $row['email'];
                header("location:../index.php");
            } else {
                echo "<span style='color:red;'>You are not user.Please Register</span>";
            }
        }
    } else {
        echo "Your email is invalid";
    }
}
?>