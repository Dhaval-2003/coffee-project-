<header id="header" class="header fixed-top">
  <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

    <a href="index.php" class="logo d-flex align-items-center">
      <img src="https://cdn.shopify.com/s/files/1/1697/1767/files/drivecoffee-logo-rgb-black_410x.png?v=1509322274" alt="">
      <!-- <span>Stone</span> -->
    </a>

    <nav id="navbar" class="navbar">
      <ul>
        <li><a class="nav-link scrollto" href="index.php">Home</a></li>
        <li><a class="nav-link scrollto" href="about.php">About</a></li>
        <!-- <li class="dropdown"><a class="nav-link scrollto" href="#">Education</a>
          <ul>
            <li><a href="">Jewellery Buying Guide</a></li>
            <li><a href="">Diamond Buying Guide</a></li>
            <li><a href="">Ring Size Guide</a></li>
            <li><a href="">Investing in Diamonds</a></li>
            <li><a href="">Conflict Free Diamonds</a></li>
          </ul>
        </li> -->
        <li class="dropdown"><a class="nav-link scrollto" href="coffee.php">Product</a>
          <ul>
            <li><a href="product.php?name=cappuccion">cappuccion Coffee</a></li>
            <li><a href="product.php?name=mocha">mocha Coffee</a></li>
            <li><a href="product.php?name=irish">irish Coffee</a></li>
            <li><a href="product.php?name=macchiato">macchiato Coffee</a></li>
            <li><a href="product.php?name=redeye">redeye Coffee</a></li>
            <li><a href="product.php?name=black">Black Coffee</a></li>
          </ul>
        </li>
        
        <li class="dropdown"><a class="nav-link scrollto" href="contact.php">Contact</a>
          <ul>
            <li><a href="contact.php">Make Appointment</a></li>
            <li><a href="partials/location.php">Location</a></li>
          </ul>
        </li>
        <?php
        session_start();
        require "connection.php";
        if (isset($_SESSION['name'])) {
          $user = $_SESSION['name'];
          $sql = "SELECT * FROM `cart` where `username`='$user'";
          $result = mysqli_query($con, $sql);
        }
        if (isset($_SESSION['name'])) {
          echo '<li class="dropdown"><a href="index.php"><span>';
          echo $_SESSION['name'];
          echo '</span><i class="bi bi-chevron-down"></i></a>
            <ul>
            <li><a href="profile.php">Profile</a></li>
            <li><a href="orders.php">Your Orders</a></li>
              <li><a href="partials/logout.php">logout</a></li>
            </ul>
            </li>
            <li><a href="cart.php"><i class="bi bi-cart" style="font-size:18px;"><sup>(' . mysqli_num_rows($result) . ')</sup></i></a></li>';
        } else {
          echo '         
          <li class="dropdown"><a href="#"><span>Get Started</span><i class="bi bi-chevron-down"></i></a>
          <ul>
            <li><a href="forms/login.php">Login</a></li>
            <li><a href="partials/register.php">Register</a></li>
          </ul>
          </li>
        </ul>';
        }
        ?>
        <i class="bi bi-list mobile-nav-toggle"></i>
    </nav><!-- .navbar -->

  </div>
</header>