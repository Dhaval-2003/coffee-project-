<?php
session_start();
if (isset($_POST['submit'])) {
    include "connection.php";
    if (empty($_POST['fname'])) {
        echo "<span style='color:red;'>Name is required</span>";
    } else {
        $fname = $_POST['fname'];
    }

    if (empty($_POST['lname'])) {
        echo "<span style='color:red;'>Last Name is required</span>";
    } else {
        $lname = $_POST['lname'];
    }

    if (empty($_POST['email'])) {
        echo "<span style='color:red;'>Email is required</span>";
    } else {
        $pattern = "/^[A-Za-z0-9]+\@[A-Za-z]+\.in|com/";
        $email = $_POST['email'];
        if (preg_match($pattern, $email)) {
            $email = $_POST['email'];
        }
    }
    $pattern = "/[A-Z]{1}[a-z]+\W[0-9]/";
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];
    if (preg_match($pattern, $password) && preg_match($pattern, $cpassword)) {
        if ($cpassword == $password) {
            $password = md5($password);
            $date = date('Y-m-d h:i:s');
            $country = $_POST['country'];
            $question = $_POST['city'];
            $sql = "INSERT into `user_info`(fname,lname,email,password,country,date,question) values('$fname','$lname','$email','$password','$country','$date','$question')";
            $result = mysqli_query($con, $sql);
            if ($result) {
                echo "<script>alert('You are register');</script>";
                $_SESSION['name'] = $fname . " " . $lname;
                // $sql2="SELECT * from `user_info` where `email`='$email'";
                // $result2=mysqli_query($con,$sql2);
                // $row=mysqli_fetch_array($result2);
                // $_SESSION['id']=$row['id'];
                $_SESSION['email'] = $email;
                header("location:../index.php");
            } else {
                echo "You are not registered";
            }
        } else {
            echo "<span style='color:red;'>Password  is not matched</span>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link href="https://cdn.shopify.com/s/files/1/1697/1767/files/drivecoffee-logo-rgb-black_410x.png?v=1509322274" rel="icon">
    <link rel="stylesheet" href="../forms/form.css">
    <link href="../assets/css/style.css" rel="stylesheet">
    <link href="../assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
</head>

<body>
    <div class="main">
        <div class="side">
            <h4 class="head">Register Now</h4>
            <br>
            <span class="head2">While seats are available</span>
           
        </div>
        <div class="form">
            <form action="" method="post">
                <table>
                    <div class="form1">
                        <tr>
                            <td><label for="fname" class="lbl">First Name <span class="req">*</span></label></td>
                        </tr>
                        <tr>
                            <td><input type="text" name="fname"></td>
                        </tr>
                        <tr>
                            <td><label for="lname" class="lbl">Last Name <span class="req">*</span></label></td>
                        </tr>
                        <tr>
                            <td><input type="text" name="lname"></td>
                        </tr>
                        <tr>
                            <td><label for="email" class="lbl">Email <span class="req">*</span></label></td>
                        </tr>
                        <tr>
                            <td><input type="email" name="email"></td>
                        </tr>
                        <tr>
                            <td><label for="password" class="lbl">Passsword <span class="req">*</span></label></td>
                        </tr>
                        <tr>
                            <td><input type="password" name="password"></td>
                        </tr>
                        <tr>
                            <td><label for="phone" class="lbl">confirm Password<span class="req">*</span></label></td>
                        </tr>
                        <tr>
                            <td><input type="password" name="cpassword"></td>
                        </tr>

                </table>
        </div>
        <div class="form2">
            <table>
                <tr>
                    <td class="lbl">Country<span class="req">*</span></td>
                </tr>
                <tr>
                    <td>
                        <select name="country" id="">
                            <option value="india">India</option>
                            <option value="rusia">Rusia</option>
                            <option value="pakistan">Pakistan</option>
                            <option value="china">china</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td class="lbl">Payment Mode<span class="req">*</span><span class="note">Payment Details</span></td>
                </tr>
                <tr>
                    <td class="pym">
                        <input type="radio" name="payment" id=""><label class="rd">Cash</label>
                        <input type="radio" name="payment" id=""><label class="rd">Cheque</label>
                        <input type="radio" name="payment" id=""><label class="rd">DD</label>
                    </td>
                </tr>
                <tr>
                    <td><label for="fname" class="lbl">What city were you born in?<span class="req">*</span></label></td>
                </tr>
                <tr>
                    <td><input type="text" name="city"></td>
                </tr>
                <tr>
                    <td class="btn" colspan="2" align="center"><button type="submit" name="submit">Submit</button><button type="reset">Reset</button></td>
                </tr>
        </div>
        </table>
        </form>
    </div>
    </div>
</body>

</html>