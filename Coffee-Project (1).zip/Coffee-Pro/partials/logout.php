<?php   
session_start();
// if(session_unset($_SESSION['name'])){
//     header("location:../index.php");
// }
session_destroy();
//unset($_SESSION['name']);
header("location:../index.php");


?>