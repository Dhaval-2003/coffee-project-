<?php
require "partials/connection.php";
$id=$_GET['id'];
$name=$_GET['name'];
$sql="SELECT * from $name where id='$id'";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_array($result);
echo "<pre>";
setcookie("id",$row['id'],time()+60*60*24*7);
setcookie("name",$row['name'],time()+60*60*24*7);
header("location:coffee.php");
?>