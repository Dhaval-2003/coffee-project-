<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About US</title>
  <link href="https://cdn.shopify.com/s/files/1/1697/1767/files/drivecoffee-logo-rgb-black_410x.png?v=1509322274" rel="icon">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <style>
    .first {
      position: relative;
      top: 100px;
      background-image: url("https://images.pexels.com/photos/683039/pexels-photo-683039.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1");
      background-attachment: fixed;
      height: 60vh;
      background-position: center;
      background-size: contain;
    }

    .second {
      position: relative;
      margin-top: 100px;
    }
  </style>
</head>

<body>
  <?php
  require('partials/nav.php');
  ?>
  <div class="container-fluid">
    <div class="first">

    </div>
  </div>
  <hr>
  <div class="container" data-aos="fade-up">
    <div class="second justify-content-center align-items-center">
      <div>
        <hr>
        <h1 class="text-center">About Us</h1>
        <hr>
        <p class="d-flex justify-content-center align-items-center">The first café is said to have opened in 1550 in Constantinople; during the 17th century cafés opened in Italy, France, Germany, and England. The coffeehouse has been a Viennese institution for three centuries.
        café, also spelled cafe, small eating and drinking establishment, historically a coffeehouse, usually featuring a limited menu; originally these establishments served only coffee. The English term café, borrowed from the French, derives ultimately from the Turkish kahve, meaning coffee.
        </p>
      </div>
      <div data-aos="fade-up">
        
        <p class="d-flex justify-content-center align-items-center">The introduction of coffee and coffee drinking to Europe provided a much-needed focus for the social activities of the sober. The first café is said to have opened in 1550 in Constantinople; during the 17th century cafés opened in Italy, France, Germany, and England.
        During the 200 years after the mid-17th century, the most famous coffeehouses of Europe flourished in London as ready points for news, discussion, and faction. Coffeehouse proprietors competed with each other for supplies of both Whig and Tory newspapers; during this time the business of buying and selling insurance, ships, stocks, commodities, and occasionally even slaves was disposed of in coffeehouses; a man of letters, an actor, or an artist might perform or declaim for his coterie in his favourite coffeehouse; and coffeehouses became informal stations for the collection and distribution of packets and letters. By the 19th century, the daily newspaper and the home post had displaced these functions.
        </p>
      </div>
      
    </div>
  </div>

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">


    <div class="footer-top">
      <div class="container">
        <div class="row gy-4">
          <div class="col-lg-5 col-md-12 footer-info">
            <a href="index.php" class="logo d-flex align-items-center">
              <span style="color: #265baa;">Coffee</span>
            </a>
            <p>The story goes that that Kaldi discovered coffee after he noticed that after eating the berries from a certain tree, his goats became so energetic that they did not want to sleep at night.</p>
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
              <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
              <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
              <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
            </div>
          </div>

         


          <div class="col-lg-3 col-md-12 footer-contact text-center text-md-start">
            <h4>Contact Us</h4>
            <p>
              A/104 V3 Shooping Complex <br>
              Adajan Gam Surat 395009<br>
              India. <br><br>
              <strong>Phone:</strong> +91 9687385603<br>
              <strong>Email:</strong> Coffee@gmail.com<br>
            </p>

          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Coffee Shop</span></strong>. All Rights Reserved
      </div>
    </div>
  </footer><!-- End Footer -->
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
</body>

</html>