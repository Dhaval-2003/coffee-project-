<?php
session_start();
include "partials/connection.php";
$id = $_GET['id'];
$name = $_GET['name'];

if (isset($name)) {
    $sql = "SELECT * FROM " . $name . " WHERE `id`='$id'";
    $result = mysqli_query($con, $sql);
    $row = mysqli_fetch_array($result);
    $product = $row["name"];
    $price = $row['price'];
    $image = $row['image'];
    $user = $_SESSION['name'];

    $sql2 = "SELECT * from `cart` where `product_name`='$product'";
    $res = mysqli_query($con, $sql2);
    if ((mysqli_num_rows($res) > 0)) {
        echo "Product is alredy added<br>";
        echo "<a href='product.php?name=" . $name . "'>Back To Product Page</a>";
    } else {
        $ins = "INSERT INTO `cart` (`product_name`,`price`,`username`,`image`) values('$product','$price','$user','$image')";
        $resu = mysqli_query($con, $ins);
        if ($resu) {
            echo "<script>alert('Product Added Successfully');</script>";
            header("location:product.php?name=" . $name);
        } else {
            echo "<script>alert('product Not added');</script>";
        }
    }
}
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $sql = "DELETE from `cart` where `id`='$id'";
    $result = mysqli_query($con, $sql);
    if ($result) {
        header("location:cart.php");
    } else {
        echo "<script>alert('Product Not Deleted');</script>";
    }
}
if(isset($_GET['all'])=="true"){
    $sql="DELETE from `cart`";
    $result=mysqli_query($con,$sql);
    if($result){
        header("location:coffee.php");
    }else{
        echo "<script>alert('Products are not deleted');</script>";
    }
}
?>