<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Coffee</title>
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="https://cdn.shopify.com/s/files/1/1697/1767/files/drivecoffee-logo-rgb-black_410x.png?v=1509322274" rel="icon">


  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <style>
    body {
      position: relative;
    }

    .error {
      display: none;
      position: fixed;
      height: 5vh;
      width: 100%;
      z-index: 1;
      top: 0;
    }

    .errorbody {
      background-color: rgba(201, 50, 47, 1);
      color: #fff;
      text-align: center;
    }
  </style>
</head>

<body>
  <?php
  require('partials/nav.php');
  ?>
  <div class="error" id="error">
    <div class="errorbody">
      <span>You Have To Login</span>
    </div>
  </div>
  <main>
<?php
include 'partials/connection.php';
$sql="SELECT * from `category` where `status`='active'";
$resu=mysqli_query($con,$sql);

?>
    <div class="container product d-flex flex-column justify-content-center align-itmes-center">
      <h3 class="text-center">COFFEE</h3>
      <div class="container text-center pro">
        <div class="row">
          
          <div class="col">
            <div class="cardd">
              <a href="product.php?name=cappuccion" onclick="return check();">
                <img src="https://images.pexels.com/photos/326869/pexels-photo-326869.jpeg" alt="">
                <div class="detail">
                  <h2>Coffee</h2>
                  <h2>Explorer</h2>
                  <input type="hidden" name="" id="sesion" value="<?php if (isset($_SESSION['name'])) echo $_SESSION['name']; ?>">
                </div>
              </a>
            </div>
          </div>
          
          <div class="col">
            <div class="cardd">
              <a href="product.php?name=mocha" onclick="return check();">
                <img src="https://images.pexels.com/photos/775878/pexels-photo-775878.jpeg" alt="">
                <div class="detail">
                  <h2>Coffee</h2>
                  <h2>Explorer</h2>
                </div>
              </a>
            </div>
          </div>
          <div class="col">
            <div class="cardd">
              <a href="product.php?name=irish" onclick="return check();">
                <img src="https://images.pexels.com/photos/290975/pexels-photo-290975.jpeg" alt="">
                <div class="detail">
                  <h2>Coffee</h2>
                  <h2>Explorer</h2>
                </div>
              </a>
            </div>
          </div>
        </div>
      </div>
      <div class="container text-center pro">
        <div class="row">
        <div class="col">
            <div class="cardd">
              <a href="product.php?name=macchiato" onclick="return check();">
                <img src="https://images.pexels.com/photos/585753/pexels-photo-585753.jpeg" alt="">
                <div class="detail">
                  <h2>Coffee</h2>
                  <h2>Explorer</h2>
                </div>
              </a>
            </div>
          </div>
          <div class="col">
            <div class="cardd">
              <a href="product.php?name=redeye" onclick="return check();">
                <img src="https://images.pexels.com/photos/5620272/pexels-photo-5620272.jpeg" alt="">
                <div class="detail">
                  <h2>Coffee</h2>
                  <h2>Explorer</h2>
                </div>
              </a>
            </div>
          </div>
          <div class="col">
            <div class="cardd">
              <a href="product.php?name=black" onclick="return check();">
                <img src="https://images.unsplash.com/photo-1497515114629-f71d768fd07c?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1484&q=80" alt="">
                <div class="detail">
                  <h2>Coffee</h2>
                  <h2>Explorer</h2>
                </div>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
  <footer id="footer" class="footer">


    <div class="footer-top">
      <div class="container">
        <div class="row gy-4">
          <div class="col-lg-5 col-md-12 footer-info">
            <a href="index.php" class="logo d-flex align-items-center">
              <span style="color: #265baa;">Coffee</span>
            </a>
            <p>The story goes that that Kaldi discovered coffee after he noticed that after eating the berries from a certain tree, his goats became so energetic that they did not want to sleep at night.</p>
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
              <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
              <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
              <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
            </div>
          </div>



          <div class="col-lg-3 col-md-12 footer-contact text-center text-md-start">
            <h4>Contact Us</h4>
            <p>
              A/104 V3 Shooping Complex <br>
              Adajan Gam Surat 395009<br>
              India. <br><br>
              <strong>Phone:</strong> +91 9687385603<br>
              <strong>Email:</strong> Coffee@gmail.com<br>
            </p>

          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Coffee</span></strong>. All Rights Reserved
      </div>
    </div>
  </footer><!-- End Footer -->
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

  <script>
    let val = document.getElementById('sesion').value;

    function check() {
      console.log(val);
      if (String(val) == '') {
        console.log("false");
        document.getElementById('error').style.display = "block";

        const v = setTimeout(out, 1000);

        function out() {
          document.getElementById('error').style.display = "none";
          // window.location.href="forms/login.php";
        }
        return false;
      } else {
        return true;
      }

    }
  </script>
</body>

</html>