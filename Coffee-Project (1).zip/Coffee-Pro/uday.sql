-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2022 at 01:56 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uday`
--

-- --------------------------------------------------------

--
-- Table structure for table `black`
--

CREATE TABLE `black` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `image` text NOT NULL,
  `status` text NOT NULL,
  `price` text NOT NULL,
  `star` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `black`
--

INSERT INTO `black` (`id`, `name`, `image`, `status`, `price`, `star`) VALUES
(1, 'Regular Black Coffee', 'black1.jpg', 'active', '15.09', '4');

-- --------------------------------------------------------

--
-- Table structure for table `cappuccion`
--

CREATE TABLE `cappuccion` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `image` text NOT NULL,
  `status` text NOT NULL,
  `price` text NOT NULL,
  `star` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cappuccion`
--

INSERT INTO `cappuccion` (`id`, `name`, `image`, `status`, `price`, `star`) VALUES
(1, 'Espresso', 'Espresso.jpg', 'active', '10.00', '5'),
(2, 'Steamed milk ', 'Steamed-milk.jpg', 'active', '15.20', '4'),
(3, 'Foam', 'foam.jpg', 'active', '15.00', '4');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(10) NOT NULL,
  `product_name` varchar(20) NOT NULL,
  `price` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `image` varchar(50) NOT NULL,
  `added_ad` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `product_name`, `price`, `username`, `image`, `added_ad`) VALUES
(67, 'Espresso', '10.00', 'Uday Vasoya', 'Espresso.jpg', '2022-08-27 11:32:07'),
(68, 'hot-water', '10.00', 'Uday Vasoya', 'hot-water.jpg', '2022-08-27 11:41:59');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `image` text NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `image`, `status`) VALUES
(16, 'black', 'black.jpg', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(10) NOT NULL,
  `email` varchar(20) NOT NULL,
  `subject` text NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `email`, `subject`, `message`) VALUES
(1, 'help@email.com', 'This is first subject', 'sgsgsgsg'),
(2, 'info@gmail.com', '', ''),
(3, 'info@gmail.com', 'This is first subject', 'This is the second content'),
(4, 'info@gmail.com', 'This is first subject', 'This is content'),
(5, 'info@gmail.com', 'This is first subject', 'this is the content'),
(6, 'info@gmail.com', 'This is first subject', 'This is the content'),
(7, 'info@gmail.com', 'This is first subject', 'This is the nth content'),
(8, 'info@gmail.com', 'This is first subject', 'this is the nth content');

-- --------------------------------------------------------

--
-- Table structure for table `irish`
--

CREATE TABLE `irish` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `image` text NOT NULL,
  `status` text NOT NULL,
  `price` text NOT NULL,
  `star` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `irish`
--

INSERT INTO `irish` (`id`, `name`, `image`, `status`, `price`, `star`) VALUES
(1, 'coffee', 'coffee.jpg', 'active', '10.00', '4'),
(2, 'whiskey coffee', 'whiskey.jpg', 'active', '25.00', '5'),
(3, 'sugar coffee', 'sugar.jpg', 'active', '20.00', '4'),
(4, 'cream', 'cream.jpg', 'active', '30.00', '5');

-- --------------------------------------------------------

--
-- Table structure for table `macchiato`
--

CREATE TABLE `macchiato` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `image` text NOT NULL,
  `status` text NOT NULL,
  `price` text NOT NULL,
  `star` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `macchiato`
--

INSERT INTO `macchiato` (`id`, `name`, `image`, `status`, `price`, `star`) VALUES
(1, 'espresso-shot', 'espresso-shot.jpg', 'active', '15.00', '5'),
(2, 'hot-water', 'hot-water.jpg', 'active', '10.00', '4');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_06_17_043548_create_notifications_table', 2),
(6, '2022_06_20_124911_create_sessions_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `mocha`
--

CREATE TABLE `mocha` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `image` text NOT NULL,
  `status` text NOT NULL,
  `price` text NOT NULL,
  `star` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mocha`
--

INSERT INTO `mocha` (`id`, `name`, `image`, `status`, `price`, `star`) VALUES
(1, 'espresso-dark', 'espresso-dark.jpg', 'active', '20.00', '4'),
(2, 'chocolate', 'chocolate.jpg', 'active', '15.00', '5'),
(3, 'steamed-milks', 'steamed-milk.jpg', 'active', '10.00', '5');

-- --------------------------------------------------------

--
-- Table structure for table `order_confirmed`
--

CREATE TABLE `order_confirmed` (
  `id` int(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `price` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `purchased_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_confirmed`
--

INSERT INTO `order_confirmed` (`id`, `username`, `price`, `address`, `purchased_at`) VALUES
(1, 'Jenish Jadav', '7000', 'Adajan Gam', '2022-05-16 09:28:57'),
(2, 'Jenish Jadav', '5000', 'Adajan Gam', '2022-05-16 13:35:55'),
(4, 'Jenish Jadav', '7000', 'Adajan Gam', '2022-05-21 11:03:14'),
(5, 'Jenish Jadav', '5000', 'Adajan Gam', '2022-06-06 11:26:54'),
(6, 'Jenish Jadav', '2500', 'Adajan Gam', '2022-06-06 11:27:38'),
(7, 'Jenish Jadav', '5000', 'Adajan Gam', '2022-06-06 11:27:55'),
(8, 'Rudresh Raval', '10', 'surat', '2022-08-27 11:09:08');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(10) NOT NULL,
  `name` text NOT NULL,
  `image` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `user_id` int(10) NOT NULL,
  `price` varchar(20) NOT NULL,
  `star` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `image`, `category_id`, `user_id`, `price`, `star`, `status`) VALUES
(1, 'R01', 'R01.jfif', 1, 2, '2500', '4', 'active'),
(2, 'R02', 'R02.jfif', 1, 0, '2500', '2', 'active'),
(3, 'R03', 'R03.jfif', 1, 0, '3500', '1', 'active'),
(4, 'R04', 'R04.jfif', 1, 0, '4500', '3', 'active'),
(5, 'B01', 'B01.png', 4, 0, '5000', '5', 'active'),
(6, 'B02', 'B02.png', 4, 0, '7000', '2', 'active'),
(7, 'B03', 'B03.png', 4, 0, '12000', '3', 'active'),
(8, 'E01', 'E01.jpg', 2, 0, '5000', '1', 'active'),
(9, 'E02', 'E02.jpg', 2, 0, '8500', '2', 'active'),
(10, 'P01', 'P01.jpeg', 3, 0, '6500', '4', 'active'),
(11, 'P02', 'P02.jpg', 3, 0, '4870', '2', 'active'),
(13, 'Solitaire Round Cut 0.50Ct', 'Solitaire Round Cut 0.50Ct.jpg', 7, 0, '5000', '3', 'active'),
(14, 'Natural White Solitaire', 'Natural White Solitaire.jpg', 7, 0, '6000', '2', 'active'),
(15, '1.00Ct Round Cut White', '1.00Ct Round Cut White.jpg', 7, 0, '6500', '4', 'active'),
(16, 'GIA Certified Natural Emerald', 'GIA Certified Natural Emerald.jpg', 7, 0, '337000', '5', 'active'),
(17, '2.00ct GIA Certified Real Cushion Cut', '2.00ct GIA Certified Real Cushion Cut.jpg', 7, 2, '500000', '4', 'active'),
(18, 'Soliatire Princess Cut GIA Certified', 'Soliatire Princess Cut GIA Certified.jpg', 7, 0, '152000', '2', 'active'),
(19, 'NP01', 'NP01.png', 6, 0, '4500', '3', 'active'),
(20, 'NP02', 'NP02.png', 6, 0, '7500', '4', 'active'),
(28, 'R0154', 'R0154.jpg', 1, 2, '50000', '3', 'active'),
(29, 'R0155', 'R0155.jpg', 1, 3, '45000', '4', 'deactivate'),
(54, 'Black Coffee -1', 'black.jpg', 16, 1, '5000', '4', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `redeye`
--

CREATE TABLE `redeye` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `image` text NOT NULL,
  `status` text NOT NULL,
  `price` text NOT NULL,
  `star` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `redeye`
--

INSERT INTO `redeye` (`id`, `name`, `image`, `status`, `price`, `star`) VALUES
(1, 'zoz-espreso', 'zoz-espreso.jpg', 'active', '30.00', '5'),
(2, 'sort-pulled ', 'sort-pulled.jpg', 'active', '20.00', '4'),
(3, 'whipped-cream', 'whipped-cream.jpg', 'active', '15.00', '5');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `id` int(10) NOT NULL,
  `fname` varchar(10) NOT NULL,
  `lname` varchar(10) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `country` varchar(20) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `question` text NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`id`, `fname`, `lname`, `email`, `password`, `country`, `date`, `question`, `status`) VALUES
(1, 'Jenish', 'Jadav', 'info@gmail.com', 'a1af9d54efd2b16c6c0d2abcd67610e2', 'India', '2022-05-17 07:19:28', 'surat', 'active'),
(2, 'User', 'User', 'userinfo@gmail.com', '448ddd517d3abb70045aea6929f02367', 'india', '2022-05-31 21:13:02', 'surat', 'active'),
(3, 'Uday', 'Vasoya', 'uday@gmail.com', '79ab5af2f180d47599bf0dd0e46a2184', 'india', '2022-08-23 07:25:53', 'surat', ''),
(4, 'Rudresh', 'Raval', 'rudreh@gmail.com', 'ae724a6755196865867c71b46a8bf263', 'india', '2022-08-26 19:38:20', 'surat', ''),
(5, 'Shubham', 'Soliya', 'Shubham@gmail', '5559e198d7a24841cae9cf5bf1f1d89e', 'india', '2022-08-26 20:14:00', 'surat', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `black`
--
ALTER TABLE `black`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cappuccion`
--
ALTER TABLE `cappuccion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `irish`
--
ALTER TABLE `irish`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `macchiato`
--
ALTER TABLE `macchiato`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mocha`
--
ALTER TABLE `mocha`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_confirmed`
--
ALTER TABLE `order_confirmed`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `redeye`
--
ALTER TABLE `redeye`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `black`
--
ALTER TABLE `black`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cappuccion`
--
ALTER TABLE `cappuccion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `irish`
--
ALTER TABLE `irish`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `macchiato`
--
ALTER TABLE `macchiato`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `mocha`
--
ALTER TABLE `mocha`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `order_confirmed`
--
ALTER TABLE `order_confirmed`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `redeye`
--
ALTER TABLE `redeye`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
