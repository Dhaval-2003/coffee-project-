<?php
session_start();
$email = $_SESSION['email'];
require "partials/connection.php";
$sql = "SELECT * from `user_info` where email='$email'";
$result = mysqli_query($con, $sql);
$row = mysqli_fetch_array($result);
if(isset($_POST['submit'])){
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $email=$_POST['email'];
    $country=$_POST['country'];
    $question=$_POST['question'];
    $sql="UPDATE `user_info` SET `fname`='$fname',`lname`='$lname',`country`='$country',`question`='$question'";
    $result=mysqli_query($con,$sql);
    if($result){
        $_SESSION['name']=$fname." ".$lname;
        $_SESSION['email']=$email;
        header("location:index.php");
    }else{
        echo "Data Not updated";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile</title>
    <link href="https://cdn.shopify.com/s/files/1/1697/1767/files/drivecoffee-logo-rgb-black_410x.png?v=1509322274" rel="icon">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        h3 {
            text-align: center;
            font-size: 25px;
        }

        .main {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        form {
            width: 90vw;
            height: 50vh;
            background-color: #ffffff;
            border-radius: 20px;
            box-shadow: 0px 25px 40px #1687d933;
        }

        .main {
            font-size: 18px;
        }

        input {
            width: 15vw;
            height: 3vh;
            border-radius: 5px;
            border: 1px solid #515151;
        }

        .main2 {
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 5px;
        }

        .main2 input {
            width: 13vw;
            height: 5vh;
            border-radius: 5px;
            background-color: #265baa;
            color: white;
            font-size: 15px;
            cursor: pointer;
            margin: 0 5px;
        }
    </style>
</head>

<body>
    <form action="" method="post">
        <h3>Update Your Profile</h3>
        <div class="main">
            <table>
                <tr>
                    <td>Enter First Name:</td>
                </tr>
                <tr></tr>
                <tr>
                    <td>Enter Last Name:</td>
                </tr>
                <tr></tr>
                <tr>
                    <td>Enter Email:</td>
                </tr>
                <tr></tr>
                <tr>
                    <td>Enter Country:</td>
                </tr>
                <tr>
                    <td>What is your Born city:</td>
                </tr>
            </table>
            <table>
                <tr>
                    <td><input type="text" name="fname" value="<?php echo $row['fname']; ?>"></td>
                </tr>
                <tr></tr>
                <tr>
                    <td><input type="text" name="lname" value="<?php echo $row['lname']; ?>"></td>
                </tr>
                <tr></tr>
                <tr>
                    <td><input type="text" name="email" value="<?php echo $row['email']; ?>"></td>
                </tr>
                <tr></tr>
                <tr>
                    <td><input type="text" name="country" value="<?php echo $row['country']; ?>"></td>
                </tr>
                <tr></tr>
                <tr>
                    <td><input type="text" name="question" value="<?php echo $row['question']; ?>"></td>
                </tr>

            </table>
        </div>
        <div class="main2">
            <input type="submit" value="Update" name="submit">
            <input type="reset" value="Reset">
        </div>
    </form>
</body>

</html>