<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>
    <link href="https://cdn.shopify.com/s/files/1/1697/1767/files/drivecoffee-logo-rgb-black_410x.png?v=1509322274" rel="icon">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>
    <?php include "partials/nav.php" ?>
    <main id="main">
        <section id="contact" class="contact">

            <div class="container" data-aos="fade-up">

                <header class="section-header">
                    <p>Contact Us</p>
                </header>

                <div class="row gy-4">

                    <div class="col-lg-6">

                        <div class="row gy-4">
                            <div class="col-md-6">
                                <div class="info-box">
                                    <i class="bi bi-geo-alt"></i>
                                    <h3>Address</h3>
                                    <p>A/104 V3 Shopping Complex,<br>Surat,395009</p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-box">
                                    <i class="bi bi-telephone"></i>
                                    <h3>Call Us</h3>
                                    <p>+91 8238315844<br>+91 9054061244</p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-box">
                                    <i class="bi bi-envelope"></i>
                                    <h3>Email Us</h3>
                                    <p>info@stone.com<br>contact@stone.com</p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-box">
                                    <i class="bi bi-clock"></i>
                                    <h3>Open Hours</h3>
                                    <p>Monday - Saturday<br>9:00AM - 07:00PM</p>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="col-lg-6">
                        <form action="forms/contact_insert.php" method="post" name="contact" class="php-email-form" onsubmit="return contactvalidate();">
                            <div class="row gy-4">

                                <div class="col-md-6">
                                    <input type="text" name="name" class="form-control" placeholder="Your Name" value="<?php if (isset($_SESSION['name'])) echo $_SESSION['name']; ?>">
                                </div>

                                <div class="col-md-6 ">
                                    <input type="email" class="form-control" name="email" placeholder="Your Email" value="<?php if (isset($_SESSION['email'])) echo $_SESSION['email']; ?>">
                                </div>

                                <div class="col-md-12">
                                    <input type="text" class="form-control" name="subject" placeholder="Subject">
                                </div>

                                <div class="col-md-12">
                                    <textarea class="form-control" name="message" rows="6" placeholder="Message"></textarea>
                                </div>

                                <div class="col-md-12 text-center">
                                    <div class="loading">Loading</div>
                                    <div class="error" id="error"></div>
                                    <div class="sent" id="sent">Your message has been sent. Thank you!</div>
                                    <button type="submit" name="send">Send Message</button>
                                </div>

                            </div>
                        </form>

                    </div>

                </div>

            </div>

        </section>
    </main>
    <?php
    include "partials/footer.php"; ?>
    <script src="assets/vendor/purecounter/purecounter.js"></script>
    <script src="assets/vendor/aos/aos.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

    <!-- Template Main JS File -->
    <script src="assets/js/main.js"></script>
    <script>
        function contactvalidate() {
            var name = document.contact.name.value;
            var email = document.contact.email.value;
            var subject = document.contact.subject.value;
            var message = document.contact.message.value;
            if (name == null || name == "") {
                document.getElementById("error").style.display = "block";
                document.getElementById("error").innerHTML = "Name is Required";
                return false;
            } else if (email == null || email == "") {
                document.getElementById("error").style.display = "block";
                document.getElementById("error").innerHTML = "Email is required";
                return false;
            } else if (subject == null || subject == "") {
                document.getElementById("error").style.display = "block";
                document.getElementById("error").innerHTML = "Subject is required";
                return false;
            } else if (message == null || message == "") {
                document.getElementById("error").style.display = "block";
                document.getElementById("error").innerHTML = "Message is required";
                return false;
            } else {
                document.getElementById("sent").style.display = "block";
                return true;

            }
        }

        function check() {
            // console.log(val);
            console.log("false");
            document.getElementById('error').style.display = "block";

            const v = setTimeout(out, 1000);

            function out() {
                document.getElementById('error').style.display = "none";
                // window.location.href="forms/login.php";

            }
        }
    </script>
</body>

</html>